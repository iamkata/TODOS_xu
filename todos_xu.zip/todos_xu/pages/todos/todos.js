Page({
  data: {
    // 文本框数据
    search: '',
    // 任务清单
    todos: [
      { name: '学习html', completed: false },
      { name: '学习hcss', completed: true },
      { name: '学习js', completed: false }
    ],
    // 剩余数量
    leftCount: 2,
    // 是否所有的标记为未完成状态
    allCompleted: false
  },
  // 监听文本输入
  inputHandle: function(e) {
    // 通过setData将文本输入的值赋值给search
    this.setData(
      // e.detail.value拿到输入的值
      { search: e.detail.value }
    )
  },
  // 点击添加按钮执行的函数
  addTodoHandle: function(e) {
    // 输入为空，不添加
    if (this.data.search.trim().length <= 0) {
      this.setData({
        search: ''
      })
      return
    }
    var newTodos =  this.data.todos
    newTodos.push(
      { name: this.data.search.trim(), completed: false }
    )
    // 必须使用setData将新的数组赋值给数据，这样界面才会刷新，因为setData内部会通知界面刷新
    this.setData({
        todos: newTodos,
        search: '',
        leftCount: this.data.leftCount + 1
      });
  },
  // 切换任务状态
  toggleTodoHandle (e) {
    console.log(e.currentTarget.dataset) // { index: 0 }
    // 获取item
    var item = this.data.todos[e.currentTarget.dataset.index]
    // 状态取反
    item.completed = !item.completed
    // 设置未完成任务数量
    var leftCount = this.data.leftCount + (item.completed ? -1 : 1)
    // 设置数据
    this.setData({
      todos: this.data.todos,
      leftCount: leftCount
    })
  },
  // 移除事件 需要注意冒泡问题
  removeTodoHandle (e) {
    var todos = this.data.todos
    // item 就是splice方法中移除掉的元素，splice方法返回的是一个数组，所以用下标获取
    var item = todos.splice(e.currentTarget.dataset.index, 1)[0]
    var leftCount = this.data.leftCount - (item.completed ? 0 : 1)
    this.setData({
      todos: todos,
      leftCount: leftCount
    })
  },
  // 切换所有
  toggleAllHandle () {
    this.data.allCompleted = !this.data.allCompleted
    var todos = this.data.todos
    todos.forEach(item => item.completed = this.data.allCompleted)
    var leftCount = this.data.allCompleted ? 0 : this.data.todos.length
    this.setData({
      todos: todos,
      leftCount: leftCount
    })
  },
  // 清除已完成任务
  clearHandle(e) {
    var todos = this.data.todos.filter(function(item) {
      return !item.completed
    })
    this.setData({
      todos: todos
    })
  }
})